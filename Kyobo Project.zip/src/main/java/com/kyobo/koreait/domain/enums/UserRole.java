package com.kyobo.koreait.domain.enums;

public enum UserRole {
    ADMIN, USER
}
